let inputValueDisplay='';
document.getElementById("screen").value=inputValueDisplay;